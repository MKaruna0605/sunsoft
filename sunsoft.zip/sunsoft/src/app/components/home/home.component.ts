import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
constructor() { 
    
  }

  ngOnInit() {
    this.galleryspin('-');
  }
  angle = 0;
 galleryspin(sign) { 
   console.log(sign);
  var spinner = document.getElementById("spinner");
 if (!sign) { this.angle = this.angle + 45; } else { this.angle = this.angle - 45; }
 spinner.style.right;
 spinner.style.webkitTransform ="rotateY("+ this.angle +"deg)";

 spinner.style.transform ="rotateY("+this. angle +"deg)";
 setTimeout(() => {
  this.galleryspin('-');
 }, 2000);
 }

 
}
